﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InvisorProject
{
    public class TenantInfo
    {
	    public string TenantName { get; set; }
	    public string TenantDescription { get; set; }
	    public string TenantCustodian { get; set; }
	    public string TenantSupportEmail { get; set; }
	    public string TenantSupportPhone { get; set; }
	    public string TenantAdvisorSupportEmail { get; set; }
	    public string TenantAdvisorSupportPhone { get; set; }
	    public string TenantButtonColor { get; set; }
	    public string TenantBKColor { get; set; }
	    public string TenantDomain { get; set; }
	    public string TenantButtonTextColor { get; set; }
	    public string TenantDefaultAdvisor { get; set; }
	    public string TenantAdvisorDomain { get; set; }
	    public string TenantDefaultFirm { get; set; }
        public string TenantOperationsSupportEmail { get; set; }
	    public TenantInfo(DbDataReader data)
	    {
		    if (data.HasRows)
		    {
			    TenantName = data["TenantName"].ToString();
			    TenantDescription = data["TenantDescription"].ToString();
			    TenantCustodian = data["TenantCustodian"].ToString();
			    TenantSupportEmail = data["TenantSupportEmail"].ToString();
			    TenantSupportPhone = data["TenantSupportPhone"].ToString();
			    TenantAdvisorSupportEmail = data["TenantAdvisorSupportEmail"].ToString();
			    TenantAdvisorSupportPhone = data["TenantAdvisorSupportPhone"].ToString();
			    TenantButtonColor = data["TenantButtonColor"].ToString();
			    TenantBKColor = data["TenantBKColor"].ToString();
			    TenantDomain = data["TenantDomain"].ToString();
			    TenantButtonTextColor = data["TenantButtonTextColor"].ToString();
			    TenantDefaultAdvisor = data["TenantDefaultAdvisor"].ToString();
			    TenantAdvisorDomain = data["TenantAdvisorDomain"].ToString();
			    TenantDefaultFirm = data["TenantDefaultFirm"].ToString();
                TenantOperationsSupportEmail = data["value"].ToString();
		    }
	    }
    }
    public partial class _Default : Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string GetTenantInfo(string tenantID)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder()
            {
                DataSource = @"localhost",
                IntegratedSecurity = true,
                InitialCatalog = @"InvisorTest"
            };

            var Serializer = new JavaScriptSerializer
            {
                MaxJsonLength = int.MaxValue
            };

            try
            {
                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("up_TenantInfo_Select", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        SqlParameter parameter = command.Parameters.Add("@TenantID", SqlDbType.Int);
                        parameter.Value = int.Parse(tenantID);

                        using (SqlDataReader data = command.ExecuteReader())
                        {
                            if (data != null && data.HasRows && data.Read())
                            {
                                TenantInfo tenantInfo = new TenantInfo(data);
                                return Serializer.Serialize(tenantInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {                
                return "Error: {ex.Message}";
            }

            return ("Error: No data found");
        }
    }
}