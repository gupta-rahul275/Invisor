USE [InvisorTest]
GO

/****** Object:  StoredProcedure [dbo].[up_TenantInfo_Select]    Script Date: 08/19/2019 23:28:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--[Stored Procedure]
CREATE PROCEDURE [dbo].[up_TenantInfo_Select] (
    @TenantID INT
    )
AS
BEGIN
    SET NOCOUNT ON;

    SELECT [Id], 
		[TenantName], 
		[TenantDescription], 
		[TenantCustodian], 
		[TenantSupportEmail], 
		[TenantSupportPhone], 
		[TenantAdvisorSupportEmail], 
		[TenantAdvisorSupportPhone], 
		[TenantButtonColor], 
		[TenantBKColor], 
		[TenantDomain],
		[TenantButtonTextColor],
		[TenantDefaultAdvisor],
		[TenantAdvisorDomain],
		[TenantDefaultFirm],
		td.[Key],
		td.Value
    FROM Tenant as t left join TenantDetails as td on t.Id=td.TenantID
       WHERE t.ID = @TenantID

END 
GO


