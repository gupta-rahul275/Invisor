declare @id table([ID] int) 

--[Sample Data]
INSERT INTO [dbo].[Tenant]
           ([TenantName]
           ,[TenantDescription]
           ,[TenantCustodian]
           ,[TenantSupportEmail]
           ,[TenantSupportPhone]
           ,[TenantAdvisorSupportEmail]
           ,[TenantButtonColor]
           ,[TenantBKColor]
           ,[TenantDomain]
           ,[TenantDefaultAdvisor]
           ,[TenantAdvisorDomain]
           ,[TenantDefaultFirm]) output inserted.Id into @id
     VALUES
           ('Its My Tenant Name'
           ,'Some Description'
           ,'The Custodian'
           ,'help@invisortest.com'
           ,'1-888-888-8888'
           ,'advisorhelp@invisortest.com'
           ,'#d9ec5a'
           ,'#103F9F'
           ,'https://invisortest.com'
           ,9999
           ,'https://advisors.invisortest.com/'
           ,8888)


insert into TenantDetails values((select * from @id),'TenantOperationsSupportEmail','operationshelp@invisortest.com')

go