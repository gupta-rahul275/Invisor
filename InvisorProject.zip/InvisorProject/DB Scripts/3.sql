USE [InvisorTest]
GO

/****** Object:  Table [dbo].[Tenant]    Script Date: 08/19/2019 23:28:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Tenant](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TenantName] [varchar](50) NOT NULL,
	[TenantDescription] [varchar](250) NULL,
	[TenantCustodian] [varchar](250) NULL,
	[TenantSupportEmail] [varchar](250) NULL,
	[TenantSupportPhone] [varchar](250) NULL,
	[TenantAdvisorSupportEmail] [varchar](250) NULL,
	[TenantAdvisorSupportPhone] [varchar](250) NULL,
	[TenantButtonColor] [varchar](250) NULL,
	[TenantBKColor] [varchar](250) NULL,
	[TenantDomain] [varchar](250) NULL,
	[TenantButtonTextColor] [varchar](250) NULL,
	[TenantDefaultAdvisor] [int] NULL,
	[TenantAdvisorDomain] [varchar](250) NULL,
	[TenantDefaultFirm] [int] NULL,
 CONSTRAINT [pkTenant] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


